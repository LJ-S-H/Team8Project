package Pack1;

public class Router {

	private static Router s0, s1, s2;
	
	private static String myIP;
	
	private static Entry[] myRoutingTable = new Entry[100000];
	
	private static boolean isUp = true;
	
	public Router(String theIP) {
		this.myIP = theIP;
	}
	

	public static Router getS0() {
		return s0;
	}

	public static void setS0(Router s0) {
		Router.s0 = s0;
		int i = 0;
		while (myRoutingTable[i] != null) {
			i++;
		}
		myRoutingTable[i] = new Entry("S0", s0.getMyIP(), 1);
		
	}

	public static Router getS1() {
		return s1;
	}

	public static void setS1(Router s1) {
		Router.s1 = s1;
		int i = 0;
		while (myRoutingTable[i] != null) {
			i++;
		}
	}

	public static Router getS2() {
		return s2;
	}

	public static void setS2(Router s2) {
		Router.s2 = s2;
		int i = 0;
		while (myRoutingTable[i] != null) {
			i++;
		}
	}

	public static String getMyIP() {
		return myIP;
	}

	public static void setMyIP(String myIP) {
		Router.myIP = myIP;
	}

	public static boolean isUp() {
		return isUp;
	}

	public static void setUp(boolean isUp) {
		Router.isUp = isUp;
	}
	
}
